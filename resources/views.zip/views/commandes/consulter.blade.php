@extends('layouts.admin')



@section('content')

<div class="container-fluid">

                        <div class="row">

                            <div class="col-lg-12">

                                <div class="card mt-2">

                                    <div class="card-header"><h3 class="font-weight-light my-4">consulter commande : </h3></div>

                                    <div class="card-body">
                                    <div class="card" style="">
                                        <div class="card-body">
                                            <h5 class="card-title">Comamnde récu </h5>
                                            <p class="card-text">                                                                                                                                      Réception de la commande recevoir ces informations : NB le PRIX de livraison affiché au livreur sera toujours de montant de livraison – 100 DA da.</p>
                                            <a href="#" class="btn btn-primary">accepter</a>
                                            <a href="#" class="btn btn-success">rejeter</a>
                                        </div>
                                    </div>



                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>





@endsection



@section('scripts')

@endsection